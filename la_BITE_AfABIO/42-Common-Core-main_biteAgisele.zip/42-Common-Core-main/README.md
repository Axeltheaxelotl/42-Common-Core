<h1 align="center">Hi 👋, I'm Fabio</h1> 
<img align="center" alt="Coding" width="400" src="https://media.tenor.com/QYcfJTtQfo8AAAAM/deku.gif">

<h3 align="left">About Me</h3>

<p align="left"> I'm a student at <a href="https://42luxembourg.lu/" target="_blank">42 Luxembourg</a> and I'm new to coding. Currently working on Push Swap. Feel free to connect with me and follow along on my coding adventures!</p>

<p align="left"> <img src="https://komarev.com/ghpvc/?username=fabiosilva24&label=Profile%20views&color=a5f3bc&style=flat" alt="fabiosilva24" /> </p>

<h3 align="left">Languages and Tools:</h3>
<p align="left"> 
    <a href="https://www.cprogramming.com/" target="_blank" rel="noreferrer"> 
        <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/c/c-original.svg" alt="c" width="40" height="40"/> 
    </a> 
    <a href="https://git-scm.com/" target="_blank" rel="noreferrer"> 
        <img src="https://www.vectorlogo.zone/logos/git-scm/git-scm-icon.svg" alt="git" width="40" height="40"/> 
    </a> 
    <a href="https://www.linux.org/" target="_blank" rel="noreferrer"> 
        <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/linux/linux-original.svg" alt="linux" width="40" height="40"/> 
    </a> 
</p>

<p align="center">
    <img src="https://github.com/fabiosilva24/42-Common-Core/blob/main/Untitled.png?raw=true" alt="42 Common Core Banner" />
</p>

### My libft Score:

![Libft Score](https://github.com/fabiosilva24/42-Common-Core/blob/main/Screenshot%20from%202024-03-13%2020-17-05.png?raw=true)

### My gnl Score:

![Gnl Score](https://github.com/fabiosilva24/42-Common-Core/blob/main/get_next_line/Screenshot%20from%202024-05-23%2016-20-40.png)

### My ft_printf:

![Ft_Printf](https://github.com/fabiosilva24/42-Common-Core/blob/main/Screenshot%20from%202024-06-20%2019-46-48.png?raw=true)

### My So_long:

![So_long](https://github.com/fabiosilva24/42-Common-Core/blob/main/so_long/score/so_long.png)
